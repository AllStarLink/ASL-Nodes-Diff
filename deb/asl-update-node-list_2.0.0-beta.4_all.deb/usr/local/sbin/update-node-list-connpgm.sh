#!/bin/bash

/usr/local/sbin/update-node-list.sh once